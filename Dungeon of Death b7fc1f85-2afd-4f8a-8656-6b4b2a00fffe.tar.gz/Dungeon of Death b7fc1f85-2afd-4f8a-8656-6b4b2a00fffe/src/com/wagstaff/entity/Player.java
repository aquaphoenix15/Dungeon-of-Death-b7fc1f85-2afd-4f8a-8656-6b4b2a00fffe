package com.wagstaff.entity;

import java.awt.*;
import java.awt.event.*;

public class Player {
    private int x;
    private int y;
    private long lastMoveTime;
    private long moveDelay = 0;
    private int speed = 32;
    private final int PANEL_WIDTH = 720;
    private final int PANEL_HEIGHT = 420;
    private final int GRID_SIZE = 32;

    public Player() {
        this.x = 0;
        this.y = 0;
        this.lastMoveTime = System.currentTimeMillis();
    }

    public void drawPlayer(Graphics g) {
        g.setColor(Color.RED);
        g.fillRect(x, y, GRID_SIZE, GRID_SIZE);
    }

    public void move(int dx, int dy) {
        x += dx;
        y += dy;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void keyPressed(KeyEvent e) {
        long currentTime = System.currentTimeMillis();

        if (currentTime - lastMoveTime < moveDelay) {
            return;
        }

        int keyCode = e.getKeyCode();

        if (keyCode == KeyEvent.VK_UP) {
            if (y - speed >= 0) {
                move(0, -speed);
            }
        } else if (keyCode == KeyEvent.VK_DOWN) {
            if (y + GRID_SIZE + speed <= PANEL_HEIGHT - GRID_SIZE) {
                move(0, speed);
            }
        } else if (keyCode == KeyEvent.VK_LEFT) {
            if (x - speed >= 0) {
                move(-speed, 0);
            }
        } else if (keyCode == KeyEvent.VK_RIGHT) {
            if (x + GRID_SIZE + speed < PANEL_WIDTH - 1) {
                move(speed, 0);
            }
        }

        lastMoveTime = currentTime;
    }
}
