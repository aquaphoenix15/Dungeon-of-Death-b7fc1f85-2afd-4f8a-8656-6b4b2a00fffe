package com.wagstaff.main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

public class DungeonGenerator {
    private static final int GRID_SIZE = 32;
    private static final int GRID_WIDTH = 720;
    private static final int GRID_HEIGHT = 420;
    private int[][] dungeon;
    private int playerX, playerY;

    public JPanel generateDungeonPanel() {
        generateDungeon();

        JPanel panel = new JPanel() {
			private static final long serialVersionUID = -4503860823474463109L; //Useless but fixed some warnings

			@Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                drawDungeon(g);
                drawPlayer(g);
            }
        };

        panel.setFocusable(true);
        panel.requestFocus();
        panel.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_R) {
                    generateDungeon();
                    panel.repaint();
                } else {
                    movePlayer(e.getKeyCode(), panel);
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
            }
        });

        return panel;
    }

    private void drawDungeon(Graphics g) {
        int rows = Math.min(GRID_WIDTH / GRID_SIZE, dungeon.length);
        int cols = Math.min(GRID_HEIGHT / GRID_SIZE, dungeon[0].length);

        for (int x = 0; x < rows; x++) {
            for (int y = 0; y < cols; y++) {
                Color color;
                switch (dungeon[x][y]) {
                    case 0:
                        color = Color.WHITE;
                        break;
                    case 1:
                        color = Color.BLACK;
                        break;
                    case 2:
                        color = Color.BLUE;
                        break;
                    default:
                        color = Color.WHITE;
                        break;
                }
                g.setColor(color);
                g.fillRect(x * GRID_SIZE, y * GRID_SIZE, GRID_SIZE, GRID_SIZE);
            }
        }
    }

    private void drawPlayer(Graphics g) {
        g.setColor(Color.RED);
        g.fillRect(playerX * GRID_SIZE, playerY * GRID_SIZE, GRID_SIZE, GRID_SIZE);
    }

    private void generateDungeon() {
        int rows = GRID_WIDTH / GRID_SIZE;
        int cols = GRID_HEIGHT / GRID_SIZE;

        dungeon = new int[rows][cols];
        Random random = new Random();

        for (int x = 0; x < rows; x++) {
            for (int y = 0; y < cols; y++) {
                dungeon[x][y] = 0; 
            }
        }

        for (int x = 1; x < rows - 1; x++) {
            for (int y = 1; y < cols - 1; y++) {
                int randomNumber = random.nextInt(10);
                if (randomNumber < 4) {
                    dungeon[x][y] = 1; 
                } else {
                    dungeon[x][y] = 0; 
                }
            }
        }

        boolean blueGenerated = false;
        while (!blueGenerated) {
            int blueX = random.nextInt(rows);
            int blueY = random.nextInt(cols);

            if (dungeon[blueX][blueY] == 0) {
                boolean adjacentToWhite = false;
                int[][] directions = { { -1, 0 }, { 1, 0 }, { 0, -1 }, { 0, 1 } };
                for (int[] dir : directions) {
                    int adjX = blueX + dir[0];
                    int adjY = blueY + dir[1];
                    if (adjX >= 0 && adjX < rows && adjY >= 0 && adjY < cols && dungeon[adjX][adjY] == 0) {
                        adjacentToWhite = true;
                        break;
                    }
                }
                if (adjacentToWhite) {
                    dungeon[blueX][blueY] = 2; 
                    blueGenerated = true;
                }
            }
        }

        do {
            playerX = random.nextInt(rows);
            playerY = random.nextInt(cols);
        } while (dungeon[playerX][playerY] == 1); 
    }

    private void movePlayer(int keyCode, JPanel panel) {
        int nextX = playerX;
        int nextY = playerY;

        switch (keyCode) {
            case KeyEvent.VK_UP:
                nextY--;
                break;
            case KeyEvent.VK_DOWN:
                if (playerY < dungeon[0].length - 2 && dungeon[playerX][playerY + 1] != 1) {
                    nextY++;
                }
                break;
            case KeyEvent.VK_LEFT:
                nextX--;
                break;
            case KeyEvent.VK_RIGHT:
                nextX++;
                break;
        }

        if (nextX >= 0 && nextX < dungeon.length && nextY >= 0 && nextY < dungeon[0].length && dungeon[nextX][nextY] != 1) {
            playerX = nextX;
            playerY = nextY;

            if (dungeon[playerX][playerY] == 2) {
                generateDungeon(); 
                panel.repaint(); 
                return; 
            }
        }

        panel.repaint(); 
    }
}
