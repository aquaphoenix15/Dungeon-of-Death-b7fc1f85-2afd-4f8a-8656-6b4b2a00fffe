package com.wagstaff.main;

import javax.swing.*;

public class Main {
    private static DungeonGenerator dungeonGenerator = new DungeonGenerator();
    public static void main(String[] args) {
        JFrame frame = new JFrame("Dungeon of Death b7fc1f85-2afd-4f8a-8656-6b4b2a00fffe 1.19.2");
        frame.setSize(720, 420);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);

        JPanel dungeonPanel = dungeonGenerator.generateDungeonPanel();

        frame.add(dungeonPanel);
        frame.setVisible(true);
    }
}
